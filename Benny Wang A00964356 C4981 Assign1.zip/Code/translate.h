#ifndef TRANSLATE_H
#define TRANSLATE_H

#include "main.h"

void parseString(char * dest, const char * src);
void translate(const int * inputPipe, const int * outputPipe);

#endif