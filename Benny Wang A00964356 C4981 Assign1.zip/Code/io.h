#ifndef IO_H
#define IO_H

#include "main.h"

void input(const int * translatePipe, const int * outputPipe);
void output(const int * inputPipe, const int * translatePipe);

#endif